Names: Maram Almutairi & Kelsey Nguyen
Project: MIPS Superscalar (project 3)
Class: CS312 — Prof. McKenney
Date: 5-5-2017


Our program doesn’t work unfortunately, we really got confused as we were doing it. So this is what we have so far.
